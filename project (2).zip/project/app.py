from flask import Flask , render_template, request
from flask_session import Session
from cs50 import SQL

from routers.account import account_route
from routers.adminpan import admin_route
from routers.shop import shop_route
from routers.settings import settings_route
from routers.check_out import checkout_route

db = SQL("sqlite:///cillex.db")

app = Flask(__name__)
app.config["SESSION_PERMANENT"] = False 
app.config["SESSION_TYPE"] = "filesystem"
Session(app)
app.register_blueprint(account_route)
app.register_blueprint(admin_route)
app.register_blueprint(shop_route)
app.register_blueprint(settings_route)
app.register_blueprint(checkout_route)
@app.route("/")
def index():
    if request.method == "GET":
        return render_template("index.html")

@app.route("/index")
def index2():
    return render_template("index.html")



@app.route("/about")
def about():
     return render_template("about.html")


@app.route("/contact")
def contact():
    return render_template("help.html")

@app.route("/item-details")
def item_details():
#     # we'll do it after we fininsh the admin panel especially add item page with database
    return render_template("item-details.html")    




