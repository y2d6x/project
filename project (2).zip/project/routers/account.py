from flask import render_template,Blueprint,request,redirect,session
from cs50 import SQL


account_route = Blueprint('account_route',__name__)


db= SQL("sqlite:///cillex.db")




@account_route.route("/login",methods =["POST","GET"])
def login():
    session_user = session.get("user_id")
    if request.method == "GET":
        if session_user:
            return redirect("logout")
        else:
            return render_template("login.html")
    else:
        phone = request.form.get("login-phone")
        password = request.form.get("login-password")
        
        user = db.execute("SELECT id, name, rules FROM users WHERE phone = ? AND pass = ?",phone,password)
        if len(user) != 1:
          
            return redirect("login")
        else:
            session["user_id"] = user[0]["id"]
            session["user_name"] = user[0]["name"]
            session["user_name"] = user[0]["rules"]
            return redirect("index")



@account_route.route("/register",methods =["POST","GET"])
def register():
    if request.method == "GET":
        return render_template("register.html")
    else:
        name = request.form.get("register-name")
        phone = request.form.get("register-phone")
        password = request.form.get("register-password")
        pass_confirm = request.form.get("register-confirm-password")
        if password != pass_confirm:
            return redirect("register")
        else:
            try:
                db.execute("INSERT INTO users(name,phone,pass) VALUES(?,?,?)",name,phone,password)
                return redirect("login")
            except Exception as error:
                if str(error) == "UNIQUE constraint failed: users.phone":
                    return render_template("register.html",error = f"The phone number {phone} is already registered")
                else:
                    print(error)
                    return render_template("register.html",error = "Something wrong error")

         


@account_route.route("/logout", methods=["POST","GET"])
def logout():
    if request.method == "GET":
        return render_template("logout.html",user_name = session.get("user_name"))
    else:
        session.clear()
        return redirect("login")