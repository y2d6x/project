from flask import Blueprint, request, render_template, redirect, url_for, flash
import os
from werkzeug.utils import secure_filename
from cs50 import SQL

# create a blueprint
admin_route = Blueprint('admin_route', __name__, template_folder='templates', static_folder='static')

# connect to the database
db = SQL("sqlite:///cillex.db")

# set the upload folder
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
# function to check if the file is allowed
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
           

# create the upload folder if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)



# route for the admin login page
@admin_route.route("/adminmanagement/admin_login", methods=["GET", "POST"])
def admin_login():
    if request.method == "GET":
        return render_template("admin_login.html")
    else:
        username = request.form.get("admin_username")
        password = request.form.get("admin_password")
        if username == "admin" and password == "cs50x2024":
            session['logged_in'] = True  # Mark the admin as logged in
            return redirect("/adminmanagement")
        else:
            flash("Invalid username or password")
            return redirect("/adminmanagement/admin_login")




# base route
@admin_route.route("/adminmanagement", methods=["GET", "POST"])
def adminmanagement():
   
    
    if request.method == "GET":
        return render_template("adminmanegment.html")

    else: 
        return redirect("/adminmanagement")

@admin_route.route("/adminmanagement/items", methods=["GET", "POST"])
def items():
    if request.method == "GET":
        # Fetch all items from the database
        items = db.execute("SELECT * FROM items")
        return render_template("adminitem.html", items=items)
    else:
        return redirect("/adminmanagement/items")




# add item route الوزك اني ههههههههه
@admin_route.route("/adminmanagement/items/additem", methods=["GET", "POST"])
def additem():
    if request.method == "GET":
        return render_template("additem.html")

    # images dictionary
    images = {
        "main_image": "main_image",
        "image1": "image1",
        "image2": "image2",
        "image3": "image3",
        "image4": "image4",
    }

    # check if the required fields are filled -->
    if not request.form.get("item") or not request.form.get("price"):
        flash("Item name and price are required.")
        return redirect("/adminmanagement/items/additem")

    paths = []
    for key, value in images.items():
        if value in request.files:
            file = request.files[value]
            if file.filename:
                filename = secure_filename(file.filename)
                if allowed_file(filename):
                    file.save(os.path.join(UPLOAD_FOLDER, filename))
                    paths.append(filename)
                else:
                    flash("Invalid file type.")
                    return redirect("/adminmanagement/items/additem")
            else:
                paths.append(None)
        else:
            paths.append(None)

    item = request.form.get("item")
    price = request.form.get("price")
    quick_description = request.form.get("quick_description")
    full_description = request.form.get("full_description")
    main_image, image1, image2, image3, image4 = paths
    it_actaive = request.form.get("it_actaive")
    
    

    # insert the data into the database حجي يوسف شلونك  -->
    db.execute( "INSERT INTO items (name, price, quick_description, full_description, main_image, image1, image2, image3, image4, it_actaive) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                 item, price, quick_description, full_description, main_image, image1, image2, image3, image4, 1)
      

    flash("Item added successfully!")
    return redirect("/adminmanagement")



# delete item route -->
@admin_route.route("/adminmanagement/items/delete", methods=["GET","POST"])
def delete():
    if request.method == "GET":
        return render_template("delete.html")
    
    # This is the route for deleting an item from the database-->
    
    item_id = request.form.get("item_id")
    try:
        db.execute("DELETE FROM items WHERE id = ?", item_id)
        flash("Item deleted successfully!")
        return redirect("/adminmanagement")
    except Exception as e:
        flash("Error deleting item: " + str(e))
        return redirect("/adminmanagement/items/delete")



# uppdate item route or edit item route whatever you want to call it -->

@admin_route.route("/adminmanagement/items/update", methods=["GET", "POST"])
def update():
    if request.method == "GET":
        return render_template("update.html")
    
    # This is the route for updating an item in the database-->
    images = {
        "main_image": "main_image",
        "image1": "image1",
        "image2": "image2",
        "image3": "image3",
        "image4": "image4",
    }
    # check if the required fields are filled -->
    if not request.form.get("item") or not request.form.get("price"):
        flash("Item name and price are required.")
        return redirect("/adminmanagement/items/update")
    

    paths = []
    for key, value in images.items():
        if value in request.files:
            file = request.files[value]
            if file.filename:
                filename = secure_filename(file.filename)
                if allowed_file(filename):
                    file.save(os.path.join(UPLOAD_FOLDER, filename))
                    paths.append(filename)
                else:
                    flash("Invalid file type.")
                    return redirect("/adminmanagement/items/update")
            else:
                paths.append(None)
        else:
            paths.append(None)

                    
    item_id = request.form.get("item_id")
    item = request.form.get("item")
    price = request.form.get("price")
    quick_description = request.form.get("quick_description")
    full_description = request.form.get("full_description")
    main_image, image1, image2, image3, image4 = paths
    it_actaive = request.form.get("it_actaive")

    # update the data in the database -->
    db.execute("UPDATE items SET name = ?, price = ?, quick_description = ?, full_description = ?, main_image = ?, image1 = ?, image2 = ?, image3 = ?, image4 = ?, it_actaive = ? WHERE id = ?", item, price, quick_description, full_description, main_image, image1, image2, image3, image4, it_actaive, item_id)

    flash("Item updated successfully!")
    return redirect("/adminmanagement")


@admin_route.route("/adminmanagement/orders", methods=["GET", "POST"])
def orders():
    if request.method == "GET":
        # Fetch all orders from the database
        orders_items = db.execute("SELECT * FROM order_items")
        orders_owner = db.execute("SELECT * FROM orders")
        return render_template("orders.html", orders_items=orders_items, orders_owner=orders_owner)
        

    else:
        return redirect("/adminmanagement/orders")





# delete account route is here -->
@admin_route.route("/adminmanagement/settings/delete_account", methods=["GET", "POST"])
def delete_account():
    if request.method == "GET":
        return render_template("delete_account.html")
    # This is the route for deleting an item from the database-->
    item_id = request.form.get("item_id")
    try:
        db.execute("DELETE FROM items WHERE id = ?", item_id)
        flash("Item deleted successfully!")
        return redirect("/adminmanagement")
    except Exception as e:
            flash("Error deleting item: " + str(e))
            return redirect("/adminmanagement/settings/delete")


#delivery route is here -->
@admin_route.route("/adminmanagement/delivery", methods=["GET", "POST"])
def delivery():
     if request.method == "GET":
        # Fetch all orders from the database 

        return render_template("delivery.html")


    
    



    
    

