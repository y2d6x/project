from flask import Blueprint, render_template, request, redirect, url_for, flash,session
from cs50 import SQL

checkout_route = Blueprint("checkout_route", __name__, template_folder="templates", static_folder="static")

db = SQL("sqlite:///cillex.db")

@checkout_route.route("/checkout", methods=["GET","POST"]) 
def checkout():
    if request.method == "GET":

        if session.get("cart"):
            cart = []
            for dic in session["cart"]:
                
                cart.append(dic.get("id"))
                

            try:
                cart_items = db.execute("select * from items where id in (?);",cart)
                count = 0
                for item in cart_items:
             
                    cart_items[count]["qty"] = session["cart"][count].get("qty")
                    count += 1       
            except:
            
                pass
                
        else:
            session["cart"] =[]
            cart_items = session["cart"]
            return redirect("shop")
   
        return render_template("checkout.html",cart = cart_items)
