from flask import Blueprint, render_template, request, redirect
from cs50 import SQL

settings_route = Blueprint("settings_route", __name__, template_folder="templates", static_folder="static") 
db = SQL("sqlite:///cillex.db")

@settings_route.route("/adminmanagement/settings", methods=["GET","POST"])
def settings():
    if request.method == "GET":
        try:
          data =  db.execute("select * from settings")
        except:
            pass

        return render_template("admin_settings.html",data = data[0])
    else:
        
        page_title = request.form.get("page_title")
        page_insta_libk = request.form.get("page_insta_libk")
        page_whatsapp_link= request.form.get("page_whatsapp_link")
        page_image_path= request.form.get("page_image_path")
        page_pgone = request.form.get("page_pgone")
        
        try:
            db.execute("update settings set page_title = ?, page_insta_libk = ?, page_whatsapp_link = ?, page_image_path = ?, page_pgone = ?",page_title,page_insta_libk,page_whatsapp_link,page_image_path,page_pgone)
        except:
            pass
        return redirect("settings")
