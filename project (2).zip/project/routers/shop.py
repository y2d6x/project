from flask import Blueprint, request, render_template, redirect, url_for, flash,session
from cs50 import SQL

# create a blueprint
shop_route = Blueprint('shop_route', __name__, template_folder='templates', static_folder='static')

#connect to the database
db = SQL("sqlite:///cillex.db")

#base route
@shop_route.route("/shop", methods=["POST","GET"])
def shop():


    if request.method == "GET":

        page_number = int(request.args.get("page_number",1))
        offset = (page_number - 1 )* 5

        try:
            items = db.execute("select * from items order by name limit 5 offset ?;",offset)
        except:
            pass    


        if session.get("cart"):
            cart = []
            for dic in session["cart"]:
                
                cart.append(dic.get("id"))

            try:
                cart_items = db.execute("select * from items where id in (?);",cart)
                count = 0
                for item in cart_items:
             
                    cart_items[count]["qty"] = session["cart"][count].get("qty")
                    count += 1       
                
            except:
            
                pass
                
        else:
            session["cart"] =[]
            cart_items = session["cart"]
          

   
        return render_template("shop.html",items = items ,cart = cart_items)
    else:
        if not session.get("user_id"):
            return redirect("login")
        else:
            cart = session.get("cart")
            for item in cart:
                if int(item.get("id")) == int(request.form.get("item_id")):
                    item["qty"] += 1
                    session["cart"] = cart
                    print(cart)
                    return redirect("shop")
          
            cart.append({"id":request.form.get("item_id"),"qty":1})
            session["cart"] = cart
            print(f"ffffff{cart}")
            return redirect("shop")
             
               




    

