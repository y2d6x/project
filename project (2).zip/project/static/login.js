// إظهار نافذة المصادقة عند الضغط على الزر
document.getElementById('auth-button').addEventListener('click', () => {
  const modal = new bootstrap.Modal(document.getElementById('auth-modal'));
  modal.show();
});

// تغيير بين صفحات تسجيل الدخول والتسجيل
document.getElementById('go-to-signup').addEventListener('click', () => showPage('signup-page'));
document.getElementById('go-to-login').addEventListener('click', () => showPage('login-page'));

// دالة لتبديل الصفحات
const showPage = (pageId) => {
  document.querySelectorAll('.page').forEach(page => page.classList.add('d-none'));
  document.getElementById(pageId).classList.remove('d-none');
};

// عملية تسجيل الدخول الوهمية
document.getElementById('login-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const modal = bootstrap.Modal.getInstance(document.getElementById('auth-modal'));
  modal.hide();
  alert("تم تسجيل الدخول بنجاح!");
});

// عملية التسجيل الوهمية
document.getElementById('signup-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const modal = bootstrap.Modal.getInstance(document.getElementById('auth-modal'));
  modal.hide();
  alert("تم إنشاء الحساب بنجاح!");
});
