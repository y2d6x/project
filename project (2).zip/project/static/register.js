//Event listener for the register form submission
document.getElementById('register-form').addEventListener('submit', function(event) {
    event.preventDefault();
  
    
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const errorMessage = document.getElementById('error-message');
  
    // Validation: Check if passwords match
    if (password !== confirmPassword) {
      errorMessage.textContent = "Passwords do not match. Please try again.";
      errorMessage.style.display = 'block';
      return;
    }
  
    // Simulate successful registration
    send = document.querySelector("#register-form").submit();
    send.addEventListener("click", sendData);
    return 
    
  });
  
