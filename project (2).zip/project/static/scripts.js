
document.querySelector('.add-to-cart').addEventListener('click', function() {
    alert('Product added to cart!');
  });
  